package com.adip.autoscreen

import android.app.admin.DeviceAdminReceiver

class ScreenAdminReceiver : DeviceAdminReceiver()
