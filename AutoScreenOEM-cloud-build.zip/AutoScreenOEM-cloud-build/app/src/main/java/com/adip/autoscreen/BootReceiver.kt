package com.adip.autoscreen

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Accessibility service is managed by Android and resumes when enabled.
        // Do not force wake or override the head unit's native ACC sleep behavior.
    }
}
