package com.adip.autoscreen

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    companion object {
    const val PREFS = "autoscreen_prefs"
    const val KEY_ENABLED = "enabled"
    const val KEY_TIMEOUT = "timeout_seconds"
    const val ACTION_SETTINGS_CHANGED = "com.adip.autoscreen.ACTION_SETTINGS_CHANGED"
    }

    private val choices = listOf("5 detik", "10 detik", "15 detik", "30 detik", "1 menit", "2 menit", "5 menit", "10 menit", "15 menit", "30 menit", "60 menit")
    private val values = listOf(5, 10, 15, 30, 60, 120, 300, 600, 900, 1800, 3600)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
            setBackgroundColor(0xFF101820.toInt())
        }
        fun text(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt()): TextView = TextView(this).apply {
            text = value; textSize = size; setTextColor(color); setPadding(0, 10, 0, 10)
        }
        root.addView(text("AutoScreen OEM", 28f))
        root.addView(text("T5-UP-F52LA · Android 13 · Allwinner", 14f, 0xFFB7C4D0.toInt()))
        root.addView(text("Display idle management", 18f))

        val enabled = Switch(this).apply {
            text = "Aktifkan Auto Screen Off"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = prefs.getBoolean(KEY_ENABLED, false)
        }
        root.addView(enabled)

        root.addView(text("Waktu tanpa aktivitas", 16f))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, choices)
        val current = prefs.getInt(KEY_TIMEOUT, 30)
        spinner.setSelection((values.indexOf(current).takeIf { it >= 0 } ?: 3))
        root.addView(spinner)

        val adminButton = Button(this).apply { text = "1. Aktifkan izin Device Admin" }
        root.addView(adminButton)
        val accessibilityButton = Button(this).apply { text = "2. Aktifkan Accessibility Service" }
        root.addView(accessibilityButton)
        val status = text("Status izin akan diperiksa saat aplikasi dibuka.", 13f, 0xFFB7C4D0.toInt())
        root.addView(status)

        val note = text("Catatan: fitur ini mengunci perangkat melalui API Android standar. Efek pada panel/backlight dan kelanjutan audio bergantung pada firmware head unit. Uji saat mobil berhenti.", 13f, 0xFFFFD18A.toInt())
        root.addView(note)

        fun save() {
            prefs.edit().putBoolean(KEY_ENABLED, enabled.isChecked)
                .putInt(KEY_TIMEOUT, values[spinner.selectedItemPosition]).apply()
            sendBroadcast(Intent(ACTION_SETTINGS_CHANGED))
        }
        enabled.setOnCheckedChangeListener { _, _ -> save() }
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { save() }
        }
        adminButton.setOnClickListener {
            val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admin = ComponentName(this, ScreenAdminReceiver::class.java)
            if (!dpm.isAdminActive(admin)) startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin))
            else Toast.makeText(this, "Device Admin sudah aktif", Toast.LENGTH_SHORT).show()
        }
        accessibilityButton.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        val testButton = Button(this).apply { text = "Tes Screen Off Sekarang" }
        root.addView(testButton)
        testButton.setOnClickListener {
            save()
            val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admin = ComponentName(this, ScreenAdminReceiver::class.java)
            if (!dpm.isAdminActive(admin)) Toast.makeText(this, "Aktifkan Device Admin terlebih dahulu", Toast.LENGTH_LONG).show()
            else dpm.lockNow()
        }

        val footer = text("OFFLINE · NO ADS · VERSION 1.0.2", 11f, 0xFF81909E.toInt()).apply { gravity = Gravity.CENTER }
        root.addView(footer)
        setContentView(ScrollView(this).apply { addView(root, ViewGroup.LayoutParams(-1, -2)) })
    }
}
