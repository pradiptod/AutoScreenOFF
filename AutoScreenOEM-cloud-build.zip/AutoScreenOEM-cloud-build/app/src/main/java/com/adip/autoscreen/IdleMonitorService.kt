package com.adip.autoscreen

import android.accessibilityservice.AccessibilityService
import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class IdleMonitorService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastLockAt = 0L
    private var receiverRegistered = false

    private val settingsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            resetIdleTimer()
        }
    }

    private val lockRunnable = Runnable {
        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(MainActivity.KEY_ENABLED, false)) return@Runnable
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(this, ScreenAdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) {
            lastLockAt = System.currentTimeMillis()
            dpm.lockNow()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (!receiverRegistered) {
            registerReceiver(settingsReceiver, IntentFilter(MainActivity.ACTION_SETTINGS_CHANGED))
            receiverRegistered = true
        }
        resetIdleTimer()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_TOUCH_INTERACTION_START,
            AccessibilityEvent.TYPE_VIEW_CLICKED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED,
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> resetIdleTimer()
        }
    }

    private fun resetIdleTimer() {
        handler.removeCallbacks(lockRunnable)
        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(MainActivity.KEY_ENABLED, false)) return
        val seconds = prefs.getInt(MainActivity.KEY_TIMEOUT, 5).coerceIn(5, 3600)
        if (System.currentTimeMillis() - lastLockAt < 5000) return
        handler.postDelayed(lockRunnable, seconds * 1000L)
    }

    override fun onInterrupt() { handler.removeCallbacks(lockRunnable) }

    override fun onDestroy() {
        handler.removeCallbacks(lockRunnable)
        if (receiverRegistered) {
            unregisterReceiver(settingsReceiver)
            receiverRegistered = false
        }
        super.onDestroy()
    }
}
