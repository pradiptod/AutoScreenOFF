package com.adip.autoscreen

import android.accessibilityservice.AccessibilityService
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class IdleMonitorService : AccessibilityService() {
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var lastLockAt = 0L

    private val lockRunnable = Runnable {
        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(MainActivity.KEY_ENABLED, false)) return@Runnable
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(this, ScreenAdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) {
            // Android's standard lock request. Actual panel/backlight behavior depends on HU firmware.
            lastLockAt = System.currentTimeMillis()
            dpm.lockNow()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        resetIdleTimer()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_TOUCH_INTERACTION_START,
            AccessibilityEvent.TYPE_VIEW_CLICKED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED,
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> resetIdleTimer()
        }
    }

    private fun resetIdleTimer() {
        handler.removeCallbacks(lockRunnable)
        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(MainActivity.KEY_ENABLED, false)) return
        val seconds = prefs.getInt(MainActivity.KEY_TIMEOUT, 300).coerceIn(30, 3600)
        // Avoid repeated lock attempts immediately after the display wakes.
        val elapsed = System.currentTimeMillis() - lastLockAt
        if (elapsed < 5000) return
        handler.postDelayed(lockRunnable, seconds * 1000L)
    }

    override fun onInterrupt() {
        handler.removeCallbacks(lockRunnable)
    }

    override fun onDestroy() {
        handler.removeCallbacks(lockRunnable)
        super.onDestroy()
    }
}
