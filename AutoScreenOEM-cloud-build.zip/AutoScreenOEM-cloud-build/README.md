# AutoScreen OEM v1.0 (prototype source)

Target device reported by user: T5-UP-F52LA, Allwinner, Android 13, 4 GB RAM.

## What this prototype does
- Provides a local settings screen (no internet permission and no ads).
- Lets the user choose an idle timeout from 30 seconds to 60 minutes.
- Uses an AccessibilityService to observe touch/click/scroll/window interaction events without retrieving window contents.
- When the idle timeout expires, requests Android to lock the device using DevicePolicyManager.lockNow().
- Leaves ACC sleep/wake behavior to the head-unit firmware/MCU.

## Important limitations
- `lockNow()` is a standard Android lock request; it is NOT a vendor-specific display power-off command. Whether the LCD/backlight actually powers down, whether audio continues, and how touch wakes the unit depend on the head-unit firmware and keyguard configuration.
- Accessibility service and Device Admin must be enabled manually by the user. The service is intentionally not hidden and does not read screen contents.
- This prototype does not claim to detect ACC. The head unit's native MCU already handles ACC sleep/wake according to the user's report.
- Test only while parked. Do not configure an unlock PIN/pattern on a vehicle head unit until wake/unlock behavior is verified.

## Build
Open this folder in Android Studio (Hedgehog or newer), allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

Requirements: Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35. No external libraries are required.

## First-run setup
1. Install the debug APK on the head unit.
2. Open AutoScreen OEM.
3. Activate Device Admin.
4. Enable AutoScreen OEM Idle Monitor in Android Accessibility settings.
5. Start with a 5-minute timeout and test while parked.
6. Verify screen, audio, wake-by-touch, and ACC sleep/wake. Disable the feature if audio stops or the unit fails to wake normally.
